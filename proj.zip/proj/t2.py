import numpy as np


arr = np.empty(5)

for i in range(5):
    arr[i] = i

print(arr[0:2])